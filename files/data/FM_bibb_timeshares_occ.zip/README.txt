OCCUPATION-BY-ACTIVITY TIME SHARES, GERMANY 2012
File: bibb2012_timeshares_isco08_2d.csv
Authors: Lukas Freund and Lukas Mann
Date: 13 November 2026


REQUIRED CITATIONS
------------------

If you use this file, please cite the BIBB data set and our paper.

Data:

  Alda, Holger; Rohrbach-Schmidt, Daniela; Tiemann, Michael (2015): BIBB
  Supplemental Task Survey to the Employment Survey 2012. SUF_2.0; Research Data
  Center at BIBB (ed.; data access); Bonn: Federal Institute for Vocational
  Education and Training. doi:10.7803/610.12.1.1.20

Paper:

  Freund, Lukas B. and Mann, Lukas F., Job Transformation, Specialization, and
  the Labor Market Effects of AI (August 16, 2025). CESifo Working Paper No.
  12072, Available at SSRN: https://ssrn.com/abstract=5466890 or
  http://dx.doi.org/10.2139/ssrn.5466890

The file contains aggregated results only. The microdata are available to
researchers from the BIBB Research Data Centre (BIBB-FDZ) and GESIS.


CONTENT
----------------------

For each of 33 occupations (ISCO-08, 2-digit), the file gives the average share
of the working day that workers spend on each of 19 activities. There is one
row per occupation and activity (33 x 19 = 627 rows). Shares sum to one within
an occupation, up to rounding.

Columns:

  occ_isco08_2d   Occupation code, ISCO-08 sub-major group
  occ_label       Occupation title (ILO)
  n_resp          Number of diary respondents in the occupation (unweighted)
  activity_id     Activity number: 1-18 standard activities, 19 other
  diary_var       Variable in the task diary (supplement, part 2)
  main_item       Matching activity item in the main survey 2012 (F303-F320)
  activity_de     Activity name, German (diary label)
  activity_en     Activity name, English
  time_share      Average share of the working day


SOURCE DATA
-----------

The Supplemental Task Survey 2012 is a follow-up to the BIBB/BAuA Employment
Survey 2012. In its second part, respondents report how much time they spent on
each activity on one working day. The scientific use file for this part has
2,272 respondents. 

The diary lists 18 standard activities. These are the activity items F303-F320
of the main survey. Respondents could add up to three activities in free text.
BIBB assigned most free-text entries to the standard activities. Activity 19,
"other", is the time on the entries that BIBB could not assign.


CONSTRUCTION
------------

Sample. We keep diary respondents whose time report is coherent according to
the BIBB quality flag (kz_zeit == 1) and who report positive working time. This
leaves 2,233 of 2,272 respondents. We drop 14 respondents without a civilian
ISCO-08 code (not coded, or armed forces). We impose no further restrictions on
region, nationality, age, or employment status. The Employment Survey covers
persons in employment aged 15 and over who work at least 10 hours per week.

Durations. We use the time variables that BIBB provides (F303_z_zeit_korr to
F323_z_zeit_korr). BIBB rescales each respondent's activity
times by a common factor so that they sum to the reported length of the working
day. Because the factor is common across a respondent's activities, it does not
affect time shares.

Activities not performed. A missing duration means that the respondent did not
perform the activity on the reporting day. We set it to zero. Every respondent
therefore enters the average for every activity, and coverage does not differ
across activities.

Normalization. For each respondent, the time share of an activity is the time
on that activity divided by total reported time on all 19 activities. Users who
want shares over the 18 common activities only can drop activity 19 and
rescale.

Occupation. The occupation is the respondent's current occupation in the main
survey, coded to ISCO-08 at the 2-digit level (variable F100_isco08_2d). We
link the diary to the main survey (BIBB/BAuA Employment Survey 2012, SUF_6.0,
doi:10.7803/501.12.1.1.60) with the interview number.

Aggregation and weights. The occupation-level share is the weighted mean of the
respondent-level shares. The weight is the extrapolation factor of the
supplement (gew_task2), which adjusts the diary sample to the population of the
main survey.

Minimum cell size. We report occupations with at least 10 diary respondents.
The number of respondents per occupation ranges from 13 to 264,
with a median of 51.